import { add } from "../src/index.js";
console.log(add(1, 2));
